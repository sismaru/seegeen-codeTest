import React, { useEffect, useState } from 'react';
import ProductItem from './Items';
import axios from 'axios';

const ProductList = () => {
  const [articles, setArticles] = useState([]);  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          '/code-test/202212', {
            headers: {
              "Content-Type" : "application/json"
            },
          }
        );
        setArticles(response.data);  
      } catch (e) {
        console.log(e);
      }
    };
  fetchData();
  }, []) 
  return (
    <ul>
      {articles?.map((article) => (
        <ProductItem key={article.seq} article={article}/>   
      ))
      }
    </ul>
  );
};

export default ProductList;