import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

/** @jsxImportSource @emotion/react */
import { css } from '@emotion/react'
import { Typography } from '@mui/material';

const titleStyle = css`
  margin-bottom: 24px;
  padding-bottom: 24px;
  border-bottom: 1px solid var(--grayD);
`
const textBlock = css`
  margin-top: 24px;
  strong{
    display: block;
    font-size: 1.2em;
    padding-bottom: 6px;
  }
`

const View = () => {
  const [details, setDetails] = useState([]);
  const { pageNum } = useParams();  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const responseD = await axios.get(
          '/code-test/202212', {
            headers: {
              "Content-Type" : "application/json"
            },
          }
        );        
        setDetails(responseD.data[pageNum].detail);
      } catch (e) {
        console.log(e);
      }
    };
  fetchData();
  }, [pageNum])  
  return (
    <div>
      <Typography variant="h4" component="h2" mb={3} css={titleStyle}>
        {details.productName}
      </Typography>

      <div css={textBlock}>
        <strong>SubTitle</strong>
        <div dangerouslySetInnerHTML={{ __html: details.subTitle }} />
      </div>
      
      <div css={textBlock}>
        <strong>OutLine</strong>
        <em dangerouslySetInnerHTML={{ __html: details.outLine }} />
      </div>
    </div>
  );
};

export default View;