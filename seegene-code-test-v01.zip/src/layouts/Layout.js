
import Grid from '@mui/material/Grid';
import ProductList from "../pages/List";
import { css } from '@emotion/react'
import View from "../pages/View";

/** @jsxImportSource @emotion/react */
const gridStyle = css`
  border-right: 1px solid #eee;
  overflow: hidden;
`;
const gridViewStyle = css`
  color: var(--dark);
  padding: 48px;
`;
const scrollY = css`
  width: calc(100% + 20px);
  height: 100vh;
  overflow-y: auto;
`

export default function RootLayout(){
  return (
    <div className="root-layout">      
      <Grid container spacing={2}>
        <Grid item xs={4} md={3} css={gridStyle}>
          <nav css={scrollY}>
            <ProductList />
          </nav>
        </Grid>
        <Grid item xs={8} md={9}>
          <main css={gridViewStyle}>
            <View />
          </main>
        </Grid>
      </Grid>      
    </div>    
  )
}