import { createBrowserRouter, Route, createRoutesFromElements, RouterProvider } from 'react-router-dom'

//pages
import List from './pages/List'
import View from './pages/View'

// layout
import Layout from './layouts/Layout';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Layout />}>
      <Route index element={<List />} />
      <Route path="view"> 
        <Route path=":pageNum" element={<View />} />
      </Route>
    </Route>
  )
)

function App() {
  return (      
    <RouterProvider router={router} />
  );
}

export default App;
